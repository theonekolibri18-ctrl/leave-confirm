package de.theon.leaveconfirm.config;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class LeaveConfirmConfigScreen extends Screen {
    private static final int WHEEL_SIZE = 128;
    private static final int WHEEL_CELL_SIZE = 8;

    private final Screen parent;
    private float hue;
    private float saturation;
    private float value;

    public LeaveConfirmConfigScreen(Screen parent) {
        super(Text.translatable("screen.leaveconfirm.config.title"));
        this.parent = parent;
        float[] hsv = rgbToHsv(LeaveConfirmConfig.getMenuColor());
        this.hue = hsv[0];
        this.saturation = hsv[1];
        this.value = hsv[2];
    }

    @Override
    protected void init() {
        int bottom = this.height / 2 + 98;
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.leaveconfirm.config.reset"), button -> {
            LeaveConfirmConfig.reset();
            syncFromConfig();
        }).dimensions(this.width / 2 - 104, bottom, 64, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.leaveconfirm.config.done"), button -> close())
                .dimensions(this.width / 2 + 40, bottom, 64, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int centerY = this.height / 2 - 12;
        int left = centerX - WHEEL_SIZE / 2;
        int top = centerY - WHEEL_SIZE / 2;

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, centerX, top - 30, 0xFFFFFFFF);
        drawColorWheel(context, left, top);
        drawPreview(context, centerX + 88, centerY - 44);

        int markerX = left + Math.round(this.hue * (WHEEL_SIZE - 1));
        int markerY = top + Math.round((1.0F - this.saturation) * (WHEEL_SIZE - 1));
        drawBorder(context, markerX - 3, markerY - 3, 7, 7, 0xFFFFFFFF);
        drawBorder(context, markerX - 2, markerY - 2, 5, 5, 0xFF000000);

        int sliderX = left;
        int sliderY = top + WHEEL_SIZE + 16;
        drawValueSlider(context, sliderX, sliderY);
        int knobX = sliderX + Math.round(this.value * WHEEL_SIZE);
        context.fill(knobX - 2, sliderY - 3, knobX + 3, sliderY + 11, 0xFFFFFFFF);
        context.fill(knobX - 1, sliderY - 2, knobX + 2, sliderY + 10, 0xFF000000);

        context.drawText(this.textRenderer, Text.literal(String.format("#%06X", LeaveConfirmConfig.getMenuColor() & 0xFFFFFF)),
                sliderX, sliderY + 18, 0xFFE6D7B0, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (updateColor(click.x(), click.y())) {
            return true;
        }

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        if (updateColor(click.x(), click.y())) {
            return true;
        }

        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public void close() {
        LeaveConfirmConfig.save();
        this.client.setScreen(this.parent);
    }

    private boolean updateColor(double mouseX, double mouseY) {
        int centerX = this.width / 2;
        int centerY = this.height / 2 - 12;
        int left = centerX - WHEEL_SIZE / 2;
        int top = centerY - WHEEL_SIZE / 2;

        if (mouseX >= left && mouseX <= left + WHEEL_SIZE && mouseY >= top && mouseY <= top + WHEEL_SIZE) {
            this.hue = clamp((float) (mouseX - left) / WHEEL_SIZE);
            this.saturation = clamp(1.0F - (float) (mouseY - top) / WHEEL_SIZE);
            applyColor();
            return true;
        }

        int sliderY = top + WHEEL_SIZE + 16;
        if (mouseX >= left && mouseX <= left + WHEEL_SIZE && mouseY >= sliderY - 4 && mouseY <= sliderY + 12) {
            this.value = clamp((float) (mouseX - left) / WHEEL_SIZE);
            applyColor();
            return true;
        }

        return false;
    }

    private void applyColor() {
        LeaveConfirmConfig.setMenuColor(hsvToRgb(this.hue, this.saturation, this.value));
    }

    private void syncFromConfig() {
        float[] hsv = rgbToHsv(LeaveConfirmConfig.getMenuColor());
        this.hue = hsv[0];
        this.saturation = hsv[1];
        this.value = hsv[2];
    }

    private void drawColorWheel(DrawContext context, int left, int top) {
        for (int x = 0; x < WHEEL_SIZE; x += WHEEL_CELL_SIZE) {
            for (int y = 0; y < WHEEL_SIZE; y += WHEEL_CELL_SIZE) {
                int color = 0xFF000000 | hsvToRgb((float) x / (WHEEL_SIZE - 1), 1.0F - (float) y / (WHEEL_SIZE - 1), this.value);
                context.fill(left + x, top + y, left + x + WHEEL_CELL_SIZE, top + y + WHEEL_CELL_SIZE, color);
            }
        }

        drawBorder(context, left - 1, top - 1, WHEEL_SIZE + 2, WHEEL_SIZE + 2, LeaveConfirmConfig.getBorderColor());
    }

    private void drawValueSlider(DrawContext context, int left, int top) {
        for (int x = 0; x <= WHEEL_SIZE; x += 2) {
            int color = 0xFF000000 | hsvToRgb(this.hue, this.saturation, (float) x / WHEEL_SIZE);
            context.fill(left + x, top, left + x + 2, top + 8, color);
        }

        drawBorder(context, left - 1, top - 1, WHEEL_SIZE + 3, 10, LeaveConfirmConfig.getBorderColor());
    }

    private void drawPreview(DrawContext context, int left, int top) {
        int boxWidth = 96;
        int boxHeight = 80;
        context.fill(left, top, left + boxWidth, top + boxHeight, 0xEE1A120A);
        context.fill(left + 2, top + 2, left + boxWidth - 2, top + boxHeight - 2, LeaveConfirmConfig.getMenuColor());
        context.fill(left + 6, top + 6, left + boxWidth - 6, top + 26, LeaveConfirmConfig.getHeaderColor());
        drawBorder(context, left, top, boxWidth, boxHeight, LeaveConfirmConfig.getBorderColor());
        context.drawTextWithShadow(this.textRenderer, Text.translatable("screen.leaveconfirm.config.preview"), left + 14, top + 13, 0xFFFFF2C4);
        context.drawText(this.textRenderer, Text.translatable("screen.leaveconfirm.confirm.yes"), left + 20, top + 48, 0xFFFFFFFF, false);
        context.drawText(this.textRenderer, Text.translatable("screen.leaveconfirm.confirm.no"), left + 56, top + 48, 0xFFFFFFFF, false);
    }

    private static int hsvToRgb(float hue, float saturation, float value) {
        int rgb = java.awt.Color.HSBtoRGB(hue, saturation, value);
        return rgb & 0xFFFFFF;
    }

    private static float[] rgbToHsv(int color) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return java.awt.Color.RGBtoHSB(r, g, b, null);
    }

    private static float clamp(float value) {
        return Math.max(0.0F, Math.min(1.0F, value));
    }

    private static void drawBorder(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + 1, color);
        context.fill(x, y + height - 1, x + width, y + height, color);
        context.fill(x, y, x + 1, y + height, color);
        context.fill(x + width - 1, y, x + width, y + height, color);
    }
}
