package de.theon.leaveconfirm.config;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class LeaveConfirmConfig {
    private static final int DEFAULT_MENU_COLOR = 0xFF332313;
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("leaveconfirm.properties");

    private static int menuColor = DEFAULT_MENU_COLOR;

    private LeaveConfirmConfig() {
    }

    public static void load() {
        if (!Files.exists(CONFIG_PATH)) {
            save();
            return;
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(CONFIG_PATH)) {
            properties.load(input);
            menuColor = parseColor(properties.getProperty("menuColor"), DEFAULT_MENU_COLOR);
        } catch (IOException ignored) {
            menuColor = DEFAULT_MENU_COLOR;
        }
    }

    public static void save() {
        Properties properties = new Properties();
        properties.setProperty("menuColor", String.format("#%06X", menuColor & 0xFFFFFF));

        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (OutputStream output = Files.newOutputStream(CONFIG_PATH)) {
                properties.store(output, "Leave Confirm settings");
            }
        } catch (IOException ignored) {
        }
    }

    public static int getMenuColor() {
        return menuColor;
    }

    public static void setMenuColor(int color) {
        menuColor = 0xFF000000 | (color & 0xFFFFFF);
    }

    public static void reset() {
        menuColor = DEFAULT_MENU_COLOR;
    }

    public static int getHeaderColor() {
        return mix(menuColor, 0xFFFFD36A, 0.28F);
    }

    public static int getBorderColor() {
        return mix(menuColor, 0xFFFFD36A, 0.62F);
    }

    public static int getInnerBorderColor() {
        return mix(menuColor, 0xFF000000, 0.35F);
    }

    private static int parseColor(String value, int fallback) {
        if (value == null || value.isBlank()) {
            return fallback;
        }

        String normalized = value.trim();
        if (normalized.startsWith("#")) {
            normalized = normalized.substring(1);
        }

        try {
            return 0xFF000000 | (Integer.parseUnsignedInt(normalized, 16) & 0xFFFFFF);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static int mix(int first, int second, float amount) {
        int r = mixChannel(first >> 16, second >> 16, amount);
        int g = mixChannel(first >> 8, second >> 8, amount);
        int b = mixChannel(first, second, amount);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int mixChannel(int first, int second, float amount) {
        return Math.round((first & 0xFF) * (1.0F - amount) + (second & 0xFF) * amount);
    }
}
