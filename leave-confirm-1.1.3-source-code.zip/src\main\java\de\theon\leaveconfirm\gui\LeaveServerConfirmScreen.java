package de.theon.leaveconfirm.gui;

import de.theon.leaveconfirm.LeaveConfirmState;
import de.theon.leaveconfirm.config.LeaveConfirmConfig;
import de.theon.leaveconfirm.mixin.GameMenuScreenAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

public class LeaveServerConfirmScreen extends Screen {
    private final Screen parent;
    private final MinecraftClient clientInstance;

    public LeaveServerConfirmScreen(Screen parent) {
        super(Text.translatable("screen.leaveconfirm.confirm.title"));
        this.parent = parent;
        this.clientInstance = MinecraftClient.getInstance();
    }

    @Override
    protected void init() {
        int boxWidth = 260;
        int boxHeight = 118;
        int left = (this.width - boxWidth) / 2;
        int top = (this.height - boxHeight) / 2;
        int buttonY = top + 78;

        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.leaveconfirm.confirm.yes"), button -> leaveServer())
                .dimensions(left + 26, buttonY, 92, 20)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.leaveconfirm.confirm.no"), button -> this.clientInstance.setScreen(this.parent))
                .dimensions(left + boxWidth - 118, buttonY, 92, 20)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int boxWidth = 260;
        int boxHeight = 118;
        int left = (this.width - boxWidth) / 2;
        int top = (this.height - boxHeight) / 2;

        context.fill(left, top, left + boxWidth, top + boxHeight, 0xEE1A120A);
        context.fill(left + 2, top + 2, left + boxWidth - 2, top + boxHeight - 2, LeaveConfirmConfig.getMenuColor());
        context.fill(left + 6, top + 6, left + boxWidth - 6, top + 32, LeaveConfirmConfig.getHeaderColor());
        drawBorder(context, left, top, boxWidth, boxHeight, LeaveConfirmConfig.getBorderColor());
        drawBorder(context, left + 4, top + 4, boxWidth - 8, boxHeight - 8, LeaveConfirmConfig.getInnerBorderColor());

        drawPlayerHead(context, left + 18, top + 42, 24);

        String playerName = this.clientInstance.player == null
                ? Text.translatable("screen.leaveconfirm.confirm.player").getString()
                : this.clientInstance.player.getName().getString();

        context.drawTextWithShadow(this.textRenderer, Text.translatable("screen.leaveconfirm.confirm.title"), left + 16, top + 15, 0xFFFFF2C4);
        context.drawTextWithShadow(this.textRenderer, Text.literal(playerName), left + 50, top + 42, 0xFFFFFFFF);
        context.drawText(this.textRenderer, Text.translatable("screen.leaveconfirm.confirm.message"), left + 50, top + 56, 0xFFE6D7B0, false);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        this.clientInstance.setScreen(this.parent);
    }

    private void drawPlayerHead(DrawContext context, int x, int y, int size) {
        ClientPlayerEntity player = this.clientInstance.player;
        PlayerListEntry entry = player == null || this.clientInstance.getNetworkHandler() == null
                ? null
                : this.clientInstance.getNetworkHandler().getPlayerListEntry(player.getUuid());
        if (entry != null) {
            PlayerSkinDrawer.draw(context, entry.getSkinTextures(), x, y, size);
            drawBorder(context, x - 2, y - 2, size + 4, size + 4, LeaveConfirmConfig.getBorderColor());
        }
    }

    private void leaveServer() {
        if (this.parent instanceof GameMenuScreen) {
            GameMenuScreenAccessor accessor = (GameMenuScreenAccessor) this.parent;
            LeaveConfirmState.allowNextDisconnect();
            accessor.leaveconfirm$invokeExitButton(accessor.leaveconfirm$getExitButton());
        }
    }

    private static void drawBorder(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + 1, color);
        context.fill(x, y + height - 1, x + width, y + height, color);
        context.fill(x, y, x + 1, y + height, color);
        context.fill(x + width - 1, y, x + width, y + height, color);
    }
}
