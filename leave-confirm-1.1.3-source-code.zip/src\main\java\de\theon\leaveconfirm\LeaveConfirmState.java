package de.theon.leaveconfirm;

public final class LeaveConfirmState {
    private static boolean allowNextDisconnect;

    private LeaveConfirmState() {
    }

    public static void allowNextDisconnect() {
        allowNextDisconnect = true;
    }

    public static boolean consumeAllowNextDisconnect() {
        if (!allowNextDisconnect) {
            return false;
        }

        allowNextDisconnect = false;
        return true;
    }
}
