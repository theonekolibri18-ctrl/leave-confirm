package de.theon.leaveconfirm.mixin;

import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(GameMenuScreen.class)
public interface GameMenuScreenAccessor {
    @Accessor("exitButton")
    ButtonWidget leaveconfirm$getExitButton();

    @Invoker("method_19836")
    void leaveconfirm$invokeExitButton(ButtonWidget button);
}
