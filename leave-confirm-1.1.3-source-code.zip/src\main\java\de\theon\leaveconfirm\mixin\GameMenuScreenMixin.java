package de.theon.leaveconfirm.mixin;

import de.theon.leaveconfirm.LeaveConfirmState;
import de.theon.leaveconfirm.gui.LeaveServerConfirmScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameMenuScreen.class)
public abstract class GameMenuScreenMixin extends Screen {
    protected GameMenuScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "method_19836", at = @At("HEAD"), cancellable = true)
    private void leaveconfirm$confirmBeforeLeaving(ButtonWidget button, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.world != null && !client.isInSingleplayer()) {
            if (LeaveConfirmState.consumeAllowNextDisconnect()) {
                return;
            }

            client.setScreen(new LeaveServerConfirmScreen((Screen) (Object) this));
            ci.cancel();
        }
    }
}
