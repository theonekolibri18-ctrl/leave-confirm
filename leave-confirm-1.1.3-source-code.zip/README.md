# Leave Confirm

Fabric client mod for Minecraft 1.21.11.

Tired of accidentally combat logging?

Leave Confirm adds a small profile-style confirmation popup before you leave a multiplayer server. Instead of instantly disconnecting when you click the leave button, you get one final choice.

When you open the escape menu on a multiplayer server and click **Server verlassen**, the mod shows a small profile-style confirmation popup:

- **Ja** leaves the server.
- **Nein** closes the popup and keeps you on the server.

## Features

- Confirmation popup before leaving multiplayer servers.
- Player head/profile-style UI.
- Mod Menu config screen.
- Custom menu color picker.
- English and German language support.

## Build

```powershell
.\gradlew.bat build
```

The built `.jar` will be in `build/libs/`.
