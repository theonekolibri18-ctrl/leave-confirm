# Leave Confirm

Tired of accidentally combat logging?

Leave Confirm is a small Fabric client mod for Minecraft 1.21.11. It adds a final confirmation popup before you leave a multiplayer server, so you do not disconnect by accident during combat or while playing.

When you open the escape menu on a multiplayer server and click the leave button, the mod shows a profile-style confirmation popup:

- **Yes** leaves the server.
- **No** closes the popup and keeps you connected.

## Features

- Confirmation popup before leaving multiplayer servers
- Helps prevent accidental combat logging
- Shows your player head in the confirmation UI
- Mod Menu support
- Configurable menu color picker
- English and German language support

## Client-side only

Leave Confirm is fully client-side. You can use it on vanilla servers, and the server does not need to install anything.

## Requirements

- Minecraft 1.21.11
- Fabric Loader
- Fabric API
- Mod Menu is optional, but recommended for the config screen

## Installation

1. Install Fabric Loader for Minecraft 1.21.11.
2. Install Fabric API.
3. Put the Leave Confirm `.jar` file into your `mods` folder.
4. Start Minecraft.

## Configuration

If Mod Menu is installed, open the Leave Confirm config screen from Mod Menu. You can change the menu color with the built-in color picker.

The config is saved in:

```text
config/leaveconfirm.properties
```

## Security disclaimer

Only download official builds from the Modrinth page or from this GitHub repository.

I am not responsible for modified, reuploaded, redistributed, repackaged, or unofficial versions of this mod. If someone changes the mod and adds malware, a RAT, token grabber, logger, spyware, adware, account stealer, or any other harmful or unwanted code, that modified version was not made, checked, or approved by me.

The official version of Leave Confirm does not contain malware, RATs, token grabbers, loggers, spyware, adware, account stealers, or code intended to steal user data.

Third-party downloads, unofficial mirrors, modified builds, or files shared by other people are used at your own risk.

## License

This project is licensed under the MIT License. See the `LICENSE` file for details.

## Build

```powershell
.\gradlew.bat build
```

The built `.jar` will be in `build/libs/`.
