package de.theon.leaveconfirm;

import de.theon.leaveconfirm.config.LeaveConfirmConfig;
import net.fabricmc.api.ClientModInitializer;

public class LeaveConfirmClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        LeaveConfirmConfig.load();
    }
}
